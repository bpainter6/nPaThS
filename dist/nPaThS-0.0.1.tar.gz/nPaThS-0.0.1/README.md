# MUTTS
A "multichannel uncoupled time-dependent thermohydraulic solver" (MUTTS) for simple, low-order multichannel analysis of light water reactor (LWR) cores
