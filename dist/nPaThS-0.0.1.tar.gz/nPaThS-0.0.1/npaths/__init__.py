from npaths.objects import *
from npaths.functions import *